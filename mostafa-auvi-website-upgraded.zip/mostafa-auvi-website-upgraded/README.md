# Mostafa Auvi Website — Upgraded Build

This is the modular, modernised build of the Mostafa Auvi author website.
It is a drop-in replacement for the original single-file `index.html` on the
existing GitHub Pages deployment.

---

## ⚠️ Protected zones (strictly untouched)

Three zones were carried over **byte-for-byte** from the original and must
not be edited:

| Zone | What | Where it lives now |
|------|------|--------------------|
| **Header border** | `.header { border-bottom: 1px solid var(--paper-dark); }` | `assets/css/layout.css` (clearly commented) |
| **Hero banner** | The `.hero` section — HTML + CSS, including inlined base64 `<img>` | HTML in `index.html` (verbatim block, commented) · CSS in `assets/css/hero.css` (verbatim) |
| **Author dashboard** | Login button `#authorLoginBtn`, modal `#loginModalOverlay`, Supabase auth logic | Button + modal HTML in `index.html` (verbatim blocks, commented) · modal/button CSS in `assets/css/auth.css` (verbatim) · auth logic in `assets/js/auth.js` (verbatim IIFE) |

Every protected block is wrapped in HTML/CSS comments that read:
`⚠️ PROTECTED — DO NOT TOUCH`.

The auth script binds to element IDs — all of these are preserved exactly:
`#authorLoginBtn #authorLoginLabel #loginModalOverlay #modalEmail
#modalPassword #modalLoginBtn #modalStatus #forgotPasswordLink
#forgotPasswordForm #resetEmail #sendResetBtn #cancelResetBtn #signupLink`.

---

## File structure

```
index.html                          Markup only (protected zones commented inline)
posts.html                          Category/search page — targeted search fix (?q= filter added)
sitemap.xml                         Expanded — 11 URLs incl. all category pages
assets/
├── css/
│   ├── tokens.css                  Design tokens (:root + a few new utility tokens)
│   ├── base.css                    Reset, page-wrap, paper texture, skip-link, back-to-top
│   ├── layout.css                  Utility bar, header (BORDER PROTECTED), nav, grids, footer
│   ├── components.css              Coming card, journal card, feat-cards, latest-writings,
│   │                                author-intro, chandradwip cover/description, accordion
│   ├── responsive.css              Consolidated mobile-first breakpoints (modifiable only)
│   ├── hero.css  ⚠️ PROTECTED      Hero banner styles — verbatim from original
│   └── auth.css  ⚠️ PROTECTED      Login button + modal chrome — verbatim from original
├── js/
│   ├── main.js                     Share/copy/toast + nav toggle, back-to-top, dynamic date,
│   │                                aria-current, focus-trap wrapper, chandradwip placeholder,
│   │                                latest-writings Supabase fetch (auto-display published articles)
│   └── auth.js   ⚠️ PROTECTED      Supabase login/session/reset/signup — verbatim IIFE
└── img/
    ├── author-intro.jpg            Decoded from the original base64 (lazy-loaded)
    └── chandradwip-extra.jpg       Placeholder — REPLACE with the real Chandradwip image
```

### Part 2 additions (targeted fixes only — no working page rewritten)

- **Search now works end-to-end.** The homepage search box was decorative; it now
  submits to `posts.html?q=<query>`. posts.html gained a `?q=` / `?search=` filter
  (client-side, after the Supabase fetch) plus a search-aware `<title>` and `<h1>`
  ("অনুসন্ধান: …"). Empty results still show the existing empty-state message.
  Tested live: `posts.html?q=চন্দ্রদ্বীপ` → title "অনুসন্ধান: চন্দ্রদ্বীপ | Mostafa Auvi".
- **Latest writings auto-display.** A lightweight `<section class="latest-writings">`
  fetches the 3 most recent published Bengali posts from the same Supabase project
  and renders them as cards. It stays hidden if Supabase is unreachable or there are
  no published posts (no empty block). Tested live: section populated with real data.
- **Sitemap expanded** from 6 → 11 URLs (all category pages + index-en.html + changefreq/priority).
- **Responsive verified** at 1280, 768, 390 — no horizontal overflow, no console errors.

Files NOT included here but required from the existing deployment (carry over unchanged):
`manifest.json`, `favicon-32.png`, `icon-192.png`, `apple-touch-icon.png`,
`apple-touch-icon-167.png`, `og-image.jpg`, `chandradwip-landscape.webp`,
`index-en.html`, `journal.html`, `posts.html`, `subscribe.html`, `about.html`,
`dashboard.html` (PROTECTED — author dashboard page).

---

## 🖼️ Chandradwip image (your request)

You asked for an image to be placed directly beneath the Chandradwip section
on the main page. The slot is ready:

1. The `<figure class="chandradwip-extra">` is already in `index.html`,
   sitting right after the Chandradwip description and before the
   pre-order CTA.
2. It references `assets/img/chandradwip-extra.jpg`.
3. A tasteful **placeholder** image ships there now so the layout is not
   broken on first deploy. `main.js` detects if the image is missing and
   shows a placeholder note automatically.
4. **To install your real image:** name it `chandradwip-extra.jpg` and drop
   it at `assets/img/chandradwip-extra.jpg` (overwrite the placeholder).
   Recommended size: 1200 × 670 px. That's it — no code change needed.

---

## What was modernised (modifiable sections only)

- **Code refactoring:** the original 1.1 MB single HTML file is split into
  7 CSS files + 2 JS files. `index.html` dropped from ~1.1 MB to ~312 KB
  (the remaining weight is the protected hero's inlined base64 image, which
  the constraints forbid touching).
- **Images:** the author-intro portrait base64 was decoded to
  `assets/img/author-intro.jpg` with `loading="lazy"`, `decoding="async"`,
  and explicit `width`/`height` (prevents layout shift). The existing
  `chandradwip-landscape.webp` gained `width`/`height`/`loading="lazy"`.
- **Responsive:** the original's duplicated 900 px / 480 px breakpoint
  blocks were merged into one mobile-first set in `responsive.css`
  (480 / 768 / 1024 / 1280). The stray `}` syntax bug in `.features-grid`
  was fixed. Hero/auth responsive rules stay in their own protected files.
- **Navigation:** added an accessible hamburger toggle for ≤ 900 px
  (with `aria-expanded`, `aria-controls`), a `role="search"` form, and
  `aria-current="page"` is applied by `main.js`.
- **Footer:** the thin `footer-strip` was rebuilt into a full
  `<footer class="site-footer">` with bio, quick-links, social, and a
  bottom bar. The PROTECTED `#authorLoginBtn` sits in the bottom bar,
  unchanged.
- **Chandradwip detail:** the long Historical Setting / Publication Status /
  Characters blocks are wrapped in a `<details>` accordion for easier reading
  (progressive enhancement — degrades to open text without JS).
- **Accessibility:** skip-link, focus-visible ring, `aria-hidden` on
  decorative ornaments/dots/arrows, `lang` attributes on language links,
  and a focus-trap wrapper around the login modal (does **not** modify
  `auth.js` — it only observes the `.open` class).
- **UX:** back-to-top button, dynamic Bengali date in the utility bar
  (`toLocaleDateString('bn-BD')`), `prefers-reduced-motion` support.

---

## Deploy

1. Copy every file in this folder into the root of the GitHub Pages repo
   (overwriting the old `index.html`).
2. Carry over the unchanged files listed above from the existing deployment.
3. Drop the real Chandradwip image at `assets/img/chandradwip-extra.jpg`.
4. Push. The Supabase auth, dashboard, hero and header border will behave
   exactly as before.
